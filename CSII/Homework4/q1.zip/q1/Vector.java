class Vector 
{ 
	Object items[]; 
	int length; 
	int size; 
	int new_size; 
	
	//renaming grow to resize
	void Resize(int new_size)
	{ 

		// check if new size is equal or greater than length 
		if(new_size < length) 
		{ 
			System.out.println("INVALID NEW SIZE"); 
			return; 
		} 
 

		// allocate new array 
		Object new_items[] = new Object[new_size]; 
		
		// copy old items into new array 
		for (int i = 0; i< length; i++) 
		{  
			new_items[i] = items[i]; 
			items = new_items; 
		} 
		//message 
		System.out.println("Vector's capacity moves to " +new_size); 
	} 

	public Vector() 
	{ 
		//create vector 
		size = 5;  
		items = new Object[5]; 
	} 

	public void Print() 
	{ 
		//message 
		System.out.println("Content: "); 

		//transverse
		for (int i = 0; i<length; i++)
			System.out.println(items[i]);  

	} 

	public void Insert(int index, Object item) 
	{ 
		// check index 
		if(index<0 || index> length) 
		{
			System.out.println("INVALID INDEX"); 
			return; 
		} 
		// resize if necessary
		if(length == size)
			Resize(new_size); 

 
		//shift elements in array by transversing the array backwards 
		for(int j = length-1; j>= index; j--) 
			// j = last element in vector 
			// j will decrease if the object we want to insert has an index less than or equal to j 
			items[j+1] = items[j]; 
		// insert new element 
		items[index] = item ; 

		//make sure to increase length 
		//
		length ++;  

		//message 
		System.out.println("inserted: " + item);  
	} 

	public void Add(Object item) 
	{ 
		Insert(length, item); 
	} 

	public void Remove(int index) 
	{ 
		// check that index is valid 
		//
		if(index<0 || index>= length) 
		{	
			System.out.println("INVALID INDEX"); 
			return; 
		} 
		int number = 0; 
		//check if vector has items in it 
		for(int a = 0; a<length; a++)  
		{ 
			if(items[a] !=  null) 
				number++;  
		}  
		//checks if utilization is at least 1 element when reduced in half AND the utilziation is less than 50%  
		if (number *2 < size && number/2>=1 ) 
		{ 
			size = size/2; 
		} 
		
  
		//message 
		System.out.println("Removing: " + items[index]);
	
		// shift element for removal 
		//  
		// transversing array forward 
	
		for(int i = index ; i< length-1; i++)  
			items[i] = items[i+1]; 
		
		
		//one less element 
		length--;   
	} 

	public int GetLength() 
	{ 
		return length; 
	} 
	
	public void Swap(int index1,int index2) 
	{ 
		Object temp = items[index1]; 
		items[index1] = items[index2]; 
		items[index2] = temp; 
	} 

} 
