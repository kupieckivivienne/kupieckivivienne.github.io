class Test 
{ 

	public static void main(String[] args) 
	{ 
		// create a vector 
		Vector v = new Vector();
	
		// add items 
		// the value is what we are passing through our vector.  
		v.Insert(0,Integer.valueOf(10)); 
		v.Insert(1,Integer.valueOf(20)); 
		v.Insert(2,Integer.valueOf(30)); 
		v.Insert(3,Integer.valueOf(40)); 
		v.Insert(4,Integer.valueOf(50));  
		
		v.Print(); 
		
		
		v.Remove(4); 
		v.Remove(3); 
		v.Remove(2); 
		v.Remove(1); 

		v.Print(); 
			

	
	} 
} 
