import java.util.Scanner; 
import java.lang.ArrayIndexOutOfBoundsException;  
import java.util.Random; 
class Test 
{ 

	  
	public static void main(String[] args) 
	{ 

		Random gen = new Random(); 

		int[] myArray = new int[6];  
		for(int i = 0; i<myArray.length; i++) 
			 myArray[i] = gen.nextInt(); 
		

		Scanner sc = new Scanner(System.in); 

		boolean outbounds = false; 
 
		while(outbounds == false)  
		{  
			//message 
			System.out.println("Enter an integer value representing an index of the array: ");  

			try 
			{ 
				int index = sc.nextInt();   
				System.out.println("The given value in the array is: " + myArray[index]); 
			} 
			catch(ArrayIndexOutOfBoundsException e) 
			{ 
				System.out.println("The index you have entered is invalid."); 
				outbounds = true; 
			} 

		}   
	
	} 
} 
